import { Entity, EntityType } from '@/types/entity';

export const MOCK_ENTITIES: Entity[] = [
  // EUROPE
  {
    id: 'fr-embassy-paris',
    type: EntityType.AMBASSADE,
    countryCode: 'FR',
    country: 'France',
    city: 'Paris',
    name: 'Ambassade du Gabon en France',
    isActive: true,
    enabledServices: ['VISA', 'PASSEPORT', 'LEGALISATION', 'CARTE_CONSULAIRE', 'TRANSCRIPTION_NAISSANCE', 'ACTE_CIVIL'],
    address: '26 bis, Avenue Raphaël, 75016 Paris, France',
    contact: {
      phone: '+33 (0)1 42 99 68 68',
      email: 'ambassade.gabonfrance@gmail.com',
      website: 'https://ambassadedugabonenfrance.com'
    }
  },
  {
    id: 'fr-consulat-paris',
    type: EntityType.CONSULAT_GENERAL,
    countryCode: 'FR',
    country: 'France',
    city: 'Paris',
    name: 'Consulat Général du Gabon à Paris',
    isActive: true,
    enabledServices: ['VISA', 'LEGALISATION', 'CARTE_CONSULAIRE', 'TRANSCRIPTION_NAISSANCE', 'ACTE_CIVIL', 'PASSEPORT'],
    address: '26 bis, Avenue Raphaël, 75016 Paris',
    contact: {
      phone: '+33 (0)1 42 99 68 62',
      email: 'cgeneralgabon@hotmail.fr'
    }
  },
  {
    id: 'gb-highcom-london',
    type: EntityType.HAUT_COMMISSARIAT,
    countryCode: 'GB',
    country: 'Royaume-Uni',
    city: 'Londres',
    name: 'Haut-Commissariat du Gabon au Royaume-Uni',
    isActive: true,
    enabledServices: ['VISA', 'PASSEPORT', 'LEGALISATION', 'CARTE_CONSULAIRE'],
    address: '27 Elvaston Place, London SW7 5NL',
    contact: {
      phone: '+44 (0)20 7823 9986',
      email: 'gabonembassyuk@gmail.com'
    }
  },
  {
    id: 'de-embassy-berlin',
    type: EntityType.AMBASSADE,
    countryCode: 'DE',
    country: 'Allemagne',
    city: 'Berlin',
    name: 'Ambassade du Gabon en Allemagne',
    isActive: true,
    enabledServices: ['VISA', 'PASSEPORT', 'LEGALISATION', 'CARTE_CONSULAIRE'],
  },
  {
    id: 'tr-embassy-ankara',
    type: EntityType.AMBASSADE,
    countryCode: 'TR',
    country: 'Turquie',
    city: 'Ankara',
    name: 'Ambassade du Gabon en Turquie',
    isActive: true,
    enabledServices: ['VISA', 'PASSEPORT', 'LEGALISATION', 'CARTE_CONSULAIRE'],
    address: '16/609 Ilkbahar Mahallesi, Oran, Çankaya, Ankara',
    contact: {
      phone: '(+90) 312 490 94 94',
      email: 'embagabonturkey@gmail.com'
    }
  },
  {
    id: 'ch-mission-geneva',
    type: EntityType.MISSION_PERMANENTE,
    countryCode: 'CH',
    country: 'Suisse',
    city: 'Genève',
    name: 'Mission Permanente du Gabon (ONU/OMC/OIT)',
    isActive: true,
    enabledServices: ['VISA', 'LEGALISATION'],
    address: 'Avenue de France 23 (3ème étage), 1202 Genève',
    contact: {
      phone: '+41 22 731 68 69',
      email: 'mission.gabon@gabon-onug.ch'
    }
  },
  {
    id: 'va-embassy-vatican',
    type: EntityType.AMBASSADE,
    countryCode: 'IT', // Using IT for Vatican location in Rome, or VA if flag exists. Using IT for consistency with text "Rome (Italie)"
    country: 'Saint-Siège (Vatican)',
    city: 'Rome',
    name: 'Ambassade du Gabon près le Saint-Siège',
    isActive: true,
    enabledServices: ['VISA', 'LEGALISATION'],
    address: 'Piazzale Clodio, 12, 00195 Rome (Italie)',
    contact: {
      phone: '+39 06 3974 5043',
      email: 'ambagabon.vatican@yahoo.com'
    }
  },

  // AFRIQUE AUSTRALE
  {
    id: 'za-embassy-pretoria',
    type: EntityType.AMBASSADE,
    countryCode: 'ZA',
    country: 'Afrique du Sud',
    city: 'Pretoria',
    name: 'Ambassade du Gabon en Afrique du Sud',
    isActive: true,
    enabledServices: ['VISA', 'PASSEPORT', 'LEGALISATION', 'CARTE_CONSULAIRE'],
    address: '921 Francis Baard Street, Arcadia, Pretoria',
    contact: {
      phone: '+27 12 430 2969',
      email: 'ambagabonsa@gmail.com'
    }
  },
  {
    id: 'ao-embassy-luanda',
    type: EntityType.AMBASSADE,
    countryCode: 'AO',
    country: 'Angola',
    city: 'Luanda',
    name: 'Ambassade du Gabon en Angola',
    isActive: true,
    enabledServices: ['VISA', 'PASSEPORT', 'LEGALISATION', 'CARTE_CONSULAIRE'],
    address: 'Rua Eng° Armindo de Andrade N°149, Miramar, Luanda',
    contact: {
      phone: '+244 222 042 943',
      email: 'ambagabonluanda@hotmail.com'
    }
  },

  // AFRIQUE CENTRALE
  {
    id: 'cm-embassy-yaounde',
    type: EntityType.AMBASSADE,
    countryCode: 'CM',
    country: 'Cameroun',
    city: 'Yaoundé',
    name: 'Ambassade du Gabon au Cameroun',
    isActive: true,
    enabledServices: ['VISA', 'PASSEPORT', 'LEGALISATION', 'CARTE_CONSULAIRE'],
    address: 'Quartier Bastos, Ekoudou, BP 4130, Yaoundé',
    contact: {
      phone: '(+237) 222 608 703',
      email: 'ambaga.cameroun@diplomatie.gouv.ga'
    }
  },
  {
    id: 'cg-embassy-brazzaville',
    type: EntityType.AMBASSADE,
    countryCode: 'CG',
    country: 'Congo',
    city: 'Brazzaville',
    name: 'Ambassade du Gabon au Congo',
    isActive: true,
    enabledServices: ['VISA', 'PASSEPORT', 'LEGALISATION', 'CARTE_CONSULAIRE'],
    address: '40, Avenue du Maréchal Lyautey, Brazzaville',
    contact: {
      phone: '(+242) 22 281 56 20',
      email: 'ambagaboncongo@diplomatie.gouv.ga'
    }
  },
  {
    id: 'cd-embassy-kinshasa',
    type: EntityType.AMBASSADE,
    countryCode: 'CD',
    country: 'RD Congo',
    city: 'Kinshasa',
    name: 'Ambassade du Gabon en RD Congo',
    isActive: true,
    enabledServices: ['VISA', 'PASSEPORT', 'LEGALISATION', 'CARTE_CONSULAIRE'],
    address: '167, avenue Colonel Mondjiba, Zone de Kintambo, Kinshasa',
    contact: {
      phone: '(+243) 971 190 647',
      email: 'rdcambassadedugabon@gmail.com'
    }
  },
  {
    id: 'gq-embassy-malabo',
    type: EntityType.AMBASSADE,
    countryCode: 'GQ',
    country: 'Guinée Équatoriale',
    city: 'Malabo',
    name: 'Ambassade du Gabon en Guinée Équatoriale',
    isActive: true,
    enabledServices: ['VISA', 'PASSEPORT', 'LEGALISATION', 'CARTE_CONSULAIRE'],
    address: 'Quartier Paraiso, Malabo',
    contact: {
      phone: '(+240) 333 093 108',
      email: 'ambagabonguineq@diplomatie.gouv.ga'
    }
  },
  {
    id: 'gq-consulat-bata',
    type: EntityType.CONSULAT_GENERAL,
    countryCode: 'GQ',
    country: 'Guinée Équatoriale',
    city: 'Bata',
    name: 'Consulat Général du Gabon à Bata',
    isActive: true,
    enabledServices: ['VISA', 'LEGALISATION', 'CARTE_CONSULAIRE'],
    address: 'Plazza del Ayuntamiento, BP 933, Bata',
    contact: {
      phone: '(+240) 222 52 80 48',
      email: 'samuelnangnang@yahoo.fr'
    }
  },
  {
    id: 'st-embassy-saotome',
    type: EntityType.AMBASSADE,
    countryCode: 'ST',
    country: 'São Tomé-et-Príncipe',
    city: 'São Tomé',
    name: 'Ambassade du Gabon à São Tomé-et-Príncipe',
    isActive: true,
    enabledServices: ['VISA', 'PASSEPORT', 'LEGALISATION', 'CARTE_CONSULAIRE'],
    address: 'Rua Damão, C.P. 394, São Tomé',
    contact: {
      phone: '(+239) 222 44 34',
      email: 'ambagabon@estome.net'
    }
  },

  // AFRIQUE DE L'OUEST
  {
    id: 'sn-embassy-dakar',
    type: EntityType.AMBASSADE,
    countryCode: 'SN',
    country: 'Sénégal',
    city: 'Dakar',
    name: 'Ambassade du Gabon au Sénégal',
    isActive: true,
    enabledServices: ['VISA', 'PASSEPORT', 'LEGALISATION', 'CARTE_CONSULAIRE'],
    address: 'Avenue Cheikh Anta Diop, BP 436, Dakar',
    contact: {
      phone: '(+221) 33 865 22 34',
      email: 'ambagabsen@diplomatie.gouv.ga'
    }
  },
  {
    id: 'ci-embassy-abidjan',
    type: EntityType.AMBASSADE,
    countryCode: 'CI',
    country: 'Côte d\'Ivoire',
    city: 'Abidjan',
    name: 'Ambassade du Gabon en Côte d\'Ivoire',
    isActive: true,
    enabledServices: ['VISA', 'PASSEPORT', 'LEGALISATION', 'CARTE_CONSULAIRE'],
    address: 'Immeuble Les Hévéas, Boulevard Carde, Plateau, Abidjan',
    contact: {
      phone: '(+225) 27 22 44 51 54',
      email: 'ambga.cotedivoire@diplomatie.gouv.ga'
    }
  },
  {
    id: 'tg-embassy-lome',
    type: EntityType.AMBASSADE,
    countryCode: 'TG',
    country: 'Togo',
    city: 'Lomé',
    name: 'Ambassade du Gabon au Togo',
    isActive: true,
    enabledServices: ['VISA', 'PASSEPORT', 'LEGALISATION', 'CARTE_CONSULAIRE'],
    address: 'Boulevard Jean Paul II, Lomé',
    contact: {
      phone: '(+228) 2226 7563',
      email: 'ambaga.togo@diplomatie.gouv.ga'
    }
  },
  {
    id: 'bj-consulat-cotonou',
    type: EntityType.CONSULAT_GENERAL,
    countryCode: 'BJ',
    country: 'Bénin',
    city: 'Cotonou',
    name: 'Consulat Général du Gabon à Cotonou',
    isActive: true,
    enabledServices: ['VISA', 'LEGALISATION', 'CARTE_CONSULAIRE'],
    address: 'Quartier Patte d’Oie Cadjèhoun, Cotonou',
    contact: {
      phone: '(+229) 64 13 22 88',
      email: 'consga.benin@diplomatie.gouv.ga'
    }
  },
  {
    id: 'ng-embassy-abuja',
    type: EntityType.AMBASSADE,
    countryCode: 'NG',
    country: 'Nigeria',
    city: 'Abuja',
    name: 'Ambassade du Gabon au Nigeria',
    isActive: true,
    enabledServices: ['VISA', 'PASSEPORT', 'LEGALISATION', 'CARTE_CONSULAIRE'],
    address: '2B, Orange Close, Off Volta Street, Maitama, Abuja',
    contact: {
      phone: '(+234) 98 734 965',
      email: 'ambagabngr@yahoo.fr'
    }
  },
  {
    id: 'ml-consulat-bamako',
    type: EntityType.CONSULAT_GENERAL,
    countryCode: 'ML',
    country: 'Mali',
    city: 'Bamako',
    name: 'Consulat Général du Gabon à Bamako',
    isActive: true,
    enabledServices: ['VISA', 'LEGALISATION', 'CARTE_CONSULAIRE'],
    address: 'Bacodjikoroni Golf, Bamako',
    contact: {
      phone: '(+223) 20 28 13 99',
      email: ''
    }
  },

  // AFRIQUE DU NORD
  {
    id: 'ma-embassy-rabat',
    type: EntityType.AMBASSADE,
    countryCode: 'MA',
    country: 'Maroc',
    city: 'Rabat',
    name: 'Ambassade du Gabon au Maroc',
    isActive: true,
    enabledServices: ['VISA', 'PASSEPORT', 'LEGALISATION', 'CARTE_CONSULAIRE'],
    address: '72 Av. Mehdi Ben Barka, Souissi, Rabat',
    contact: {
      phone: '+212 537 75 19 50',
      email: 'ambga.maroc@diplomatie.gouv.ga'
    }
  },
  {
    id: 'ma-consulat-laayoune',
    type: EntityType.CONSULAT_GENERAL,
    countryCode: 'MA',
    country: 'Maroc',
    city: 'Laâyoune',
    name: 'Consulat Général du Gabon à Laâyoune',
    isActive: true,
    enabledServices: ['VISA', 'LEGALISATION', 'CARTE_CONSULAIRE'],
  },
  {
    id: 'dz-embassy-alger',
    type: EntityType.AMBASSADE,
    countryCode: 'DZ',
    country: 'Algérie',
    city: 'Alger',
    name: 'Ambassade du Gabon en Algérie',
    isActive: true,
    enabledServices: ['VISA', 'PASSEPORT', 'LEGALISATION', 'CARTE_CONSULAIRE'],
    address: 'Villa N°2, Impasse Ahmed Kara, Alger',
    contact: {
      phone: '(+213) 23 38 12 36',
      email: 'ambaga.algerie@diplomatie.gouv.ga'
    }
  },
  {
    id: 'tn-embassy-tunis',
    type: EntityType.AMBASSADE,
    countryCode: 'TN',
    country: 'Tunisie',
    city: 'Tunis',
    name: 'Ambassade du Gabon en Tunisie',
    isActive: true,
    enabledServices: ['VISA', 'PASSEPORT', 'LEGALISATION', 'CARTE_CONSULAIRE'],
    address: '7, Rue de l’Ile de Rhodes, Les Jardins de Lac II, Tunis',
    contact: {
      phone: '(+216) 71 197 216',
      email: 'ambassadegabon.tn@gmail.com'
    }
  },
  {
    id: 'eg-embassy-cairo',
    type: EntityType.AMBASSADE,
    countryCode: 'EG',
    country: 'Égypte',
    city: 'Le Caire',
    name: 'Ambassade du Gabon en Égypte',
    isActive: true,
    enabledServices: ['VISA', 'PASSEPORT', 'LEGALISATION', 'CARTE_CONSULAIRE'],
    address: '59, rue Syrie, Mohandessine, Le Caire',
    contact: {
      phone: '+20 2 304 39 72',
      email: 'amba.gabon@yahoo.fr'
    }
  },

  // UNION AFRICAINE
  {
    id: 'et-embassy-addis',
    type: EntityType.AMBASSADE,
    countryCode: 'ET',
    country: 'Éthiopie',
    city: 'Addis-Abeba',
    name: 'Ambassade du Gabon en Éthiopie (UA)',
    isActive: true,
    enabledServices: ['VISA', 'PASSEPORT', 'LEGALISATION', 'CARTE_CONSULAIRE'],
    address: 'Bole Sub City, Kebele-18, H. No. 1026, Addis-Abeba',
    contact: {
      phone: '(+251) 116 61 10 75',
      email: 'ambagabaddis@gmail.com'
    }
  },

  // AMÉRIQUES
  {
    id: 'us-embassy-washington',
    type: EntityType.AMBASSADE,
    countryCode: 'US',
    country: 'États-Unis',
    city: 'Washington D.C.',
    name: 'Ambassade du Gabon aux États-Unis',
    isActive: true,
    enabledServices: ['VISA', 'PASSEPORT', 'LEGALISATION', 'CARTE_CONSULAIRE'],
    address: '2034 20th Street NW, Suite 200, Washington, DC 20009',
    contact: {
      phone: '+1 (202) 797-1000',
      email: 'info@gabonembassyusa.org',
      website: 'https://www.gabonembassyusa.org'
    }
  },
  {
    id: 'us-consulat-newyork',
    type: EntityType.CONSULAT_GENERAL,
    countryCode: 'US',
    country: 'États-Unis',
    city: 'New York',
    name: 'Consulat Général du Gabon à New York',
    isActive: true,
    enabledServices: ['VISA', 'LEGALISATION', 'CARTE_CONSULAIRE'],
    address: '122 East 42nd Street, Suite 519, New York, NY 10168',
    contact: {
      phone: '+1 (212) 683-7371',
      email: 'consulatgabon@aol.com'
    }
  },
  {
    id: 'us-mission-un-newyork',
    type: EntityType.MISSION_PERMANENTE,
    countryCode: 'US',
    country: 'États-Unis',
    city: 'New York',
    name: 'Mission Permanente du Gabon (ONU)',
    isActive: true,
    enabledServices: ['VISA', 'LEGALISATION'],
    address: '18 East 41st Street, 9th Floor, New York, NY 10017',
    contact: {
      phone: '+1 (212) 686-9720',
      email: 'info@gabonunmission.com'
    }
  },
  {
    id: 'ca-embassy-ottawa',
    type: EntityType.AMBASSADE,
    countryCode: 'CA',
    country: 'Canada',
    city: 'Ottawa',
    name: 'Ambassade du Gabon au Canada',
    isActive: true,
    enabledServices: ['VISA', 'PASSEPORT', 'LEGALISATION', 'CARTE_CONSULAIRE'],
    address: 'Ottawa, Canada',
    contact: {
      phone: '+1 613 232 5301',
      email: '',
      website: 'https://www.ambassadegabon.ca'
    }
  },
  {
    id: 'cu-embassy-havana',
    type: EntityType.AMBASSADE,
    countryCode: 'CU',
    country: 'Cuba',
    city: 'La Havane',
    name: 'Ambassade du Gabon à Cuba',
    isActive: true,
    enabledServices: ['VISA', 'PASSEPORT', 'LEGALISATION', 'CARTE_CONSULAIRE'],
    address: '9 Turrana Street, La Havane',
    contact: {
      phone: '(+53) 7 51 210 0200',
      email: ''
    }
  },

  // ASIE & MOYEN-ORIENT
  {
    id: 'cn-embassy-beijing',
    type: EntityType.AMBASSADE,
    countryCode: 'CN',
    country: 'Chine',
    city: 'Pékin',
    name: 'Ambassade du Gabon en Chine',
    isActive: true,
    enabledServices: ['VISA', 'PASSEPORT', 'LEGALISATION', 'CARTE_CONSULAIRE'],
    address: '36, Guang Hua Lu, Jian Guo Men Wai, Beijing 100600',
    contact: {
      phone: '(+86) 10 6532 2810',
      email: 'ambagabonchine@yahoo.fr'
    }
  },
  {
    id: 'jp-embassy-tokyo',
    type: EntityType.AMBASSADE,
    countryCode: 'JP',
    country: 'Japon',
    city: 'Tokyo',
    name: 'Ambassade du Gabon au Japon',
    isActive: true,
    enabledServices: ['VISA', 'PASSEPORT', 'LEGALISATION', 'CARTE_CONSULAIRE'],
    address: '1-34-11, Higashigaoka, Meguro-ku, Tokyo 152-0021',
    contact: {
      phone: '(+81) 3 5430 9171',
      email: 'info@gabonembassy-tokyo.org'
    }
  },
  {
    id: 'kr-embassy-seoul',
    type: EntityType.AMBASSADE,
    countryCode: 'KR',
    country: 'Corée du Sud',
    city: 'Séoul',
    name: 'Ambassade du Gabon en Corée du Sud',
    isActive: true,
    enabledServices: ['VISA', 'PASSEPORT', 'LEGALISATION', 'CARTE_CONSULAIRE'],
    address: '4th Floor, Yoosung Building, 239 Itaewon-ro, Yongsan-gu, Séoul 04348',
    contact: {
      phone: '(+82) 2 793 9575',
      email: 'amgabsel@unitel.co.kr'
    }
  },
  {
    id: 'in-embassy-newdelhi',
    type: EntityType.AMBASSADE,
    countryCode: 'IN',
    country: 'Inde',
    city: 'New Delhi',
    name: 'Ambassade du Gabon en Inde',
    isActive: true,
    enabledServices: ['VISA', 'PASSEPORT', 'LEGALISATION', 'CARTE_CONSULAIRE'],
    address: 'E-84, Paschimi Marg, Vasant Vihar, New Delhi - 110057',
    contact: {
      phone: '(+91) 11 4101 2513',
      email: 'gabon.secretariat22@gmail.com',
      website: 'https://www.gabonembassynewdelhi.com'
    }
  },
  {
    id: 'sa-embassy-riyadh',
    type: EntityType.AMBASSADE,
    countryCode: 'SA',
    country: 'Arabie Saoudite',
    city: 'Riyad',
    name: 'Ambassade du Gabon en Arabie Saoudite',
    isActive: true,
    enabledServices: ['VISA', 'PASSEPORT', 'LEGALISATION', 'CARTE_CONSULAIRE'],
    address: 'Al-Morsalat Q. Bin Tofiel Street, P.O. Box 94325, Riyadh 11693',
    contact: {
      phone: '(+966) 11 456 7173',
      email: 'ambagabonriyadh@yahoo.com'
    }
  },
  {
    id: 'lb-embassy-beirut',
    type: EntityType.AMBASSADE,
    countryCode: 'LB',
    country: 'Liban',
    city: 'Beyrouth',
    name: 'Ambassade du Gabon au Liban',
    isActive: true,
    enabledServices: ['VISA', 'PASSEPORT', 'LEGALISATION', 'CARTE_CONSULAIRE'],
    address: 'Beyrouth, Liban',
    contact: {
      phone: '+961 5 956 048',
      email: ''
    }
  },
];

export const getEntityById = (id: string): Entity | undefined => {
  return MOCK_ENTITIES.find(entity => entity.id === id);
};

export const getEntitiesByCountry = (countryCode: string): Entity[] => {
  return MOCK_ENTITIES.filter(entity => entity.countryCode === countryCode);
};
