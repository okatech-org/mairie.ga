import { DemoUser } from '@/types/roles';
import { ConsularRole, EmploymentStatus } from '@/types/consular-roles';
import { MOCK_ENTITIES } from './mock-entities';
import { Entity, EntityType } from '@/types/entity';
import { MOCK_GABONAIS_CITIZENS } from './mock-citizens';
import { MOCK_FOREIGNERS } from './mock-foreigners';

// --- STATIC USERS (Admin & Citizens) ---

const ADMIN_USER: DemoUser = {
  id: 'admin-system',
  role: 'ADMIN',
  name: 'Super Admin',
  entityId: undefined,
  permissions: [
    'Accès total au système',
    'Gestion des licences',
    'Création d\'entités',
    'Configuration IA et sécurité',
    'Consultation des logs système',
    'Gestion des utilisateurs globale',
  ],
  badge: '🔴',
  description: 'Super administrateur avec accès au réseau mondial complet',
};

// --- DYNAMIC STAFF GENERATION ---

const generateStaffForEntity = (entity: Entity): DemoUser[] => {
  const staff: DemoUser[] = [];
  const entityType = entity.type;
  const city = entity.city;
  const idPrefix = entity.id.split('-').slice(0, 2).join('-'); // e.g., fr-consulat

  // 1. CONSUL GENERAL (Only for CONSULAT_GENERAL)
  if (entityType === EntityType.CONSULAT_GENERAL) {
    staff.push({
      id: `${idPrefix}-cg`,
      role: ConsularRole.CONSUL_GENERAL,
      name: `M. le Consul Général (${city})`,
      entityId: entity.id,
      hierarchyLevel: 1,
      employmentStatus: EmploymentStatus.FONCTIONNAIRE,
      allowedEntityTypes: [EntityType.CONSULAT_GENERAL],
      permissions: ['Supervision globale', 'Direction stratégique', 'Administration générale'],
      badge: '🥇',
      description: 'Consul Général - Chef de Poste',
    });
  }

  // 2. CONSUL (All entities)
  staff.push({
    id: `${idPrefix}-consul`,
    role: ConsularRole.CONSUL,
    name: `Consul (${city})`,
    entityId: entity.id,
    hierarchyLevel: 2,
    employmentStatus: EmploymentStatus.FONCTIONNAIRE,
    allowedEntityTypes: [EntityType.CONSULAT_GENERAL, EntityType.CONSULAT, EntityType.AMBASSADE],
    permissions: entityType === EntityType.CONSULAT_GENERAL
      ? ['Direction adjointe', 'Gestion entité']
      : ['Direction section consulaire', 'Responsable principal'],
    badge: '🥈',
    description: entityType === EntityType.CONSULAT_GENERAL ? 'Consul - Adjoint au Chef de Poste' : 'Consul - Chef de Section Consulaire',
  });

  // 3. VICE-CONSUL (Only for CONSULAT and CONSULAT_GENERAL)
  if (entityType === EntityType.CONSULAT || entityType === EntityType.CONSULAT_GENERAL) {
    staff.push({
      id: `${idPrefix}-vc`,
      role: ConsularRole.VICE_CONSUL,
      name: `Vice-Consul (${city})`,
      entityId: entity.id,
      hierarchyLevel: 3,
      employmentStatus: EmploymentStatus.FONCTIONNAIRE,
      allowedEntityTypes: [EntityType.CONSULAT_GENERAL, EntityType.CONSULAT],
      permissions: ['Supervision opérations', 'Validation'],
      badge: '🥉',
      description: 'Vice-Consul - Supervision Opérationnelle',
    });
  }

  // 4. CHARGE D'AFFAIRES CONSULAIRES (All entities)
  staff.push({
    id: `${idPrefix}-cac`,
    role: ConsularRole.CHARGE_AFFAIRES_CONSULAIRES,
    name: `Chargé d'Affaires (${city})`,
    entityId: entity.id,
    hierarchyLevel: 4,
    employmentStatus: EmploymentStatus.FONCTIONNAIRE,
    allowedEntityTypes: [EntityType.CONSULAT_GENERAL, EntityType.CONSULAT, EntityType.AMBASSADE],
    permissions: ['Gestion demandes', 'Validation dossiers'],
    badge: '🎖️',
    description: 'Chargé d\'Affaires Consulaires',
  });

  // 5. AGENT CONSULAIRE (All entities - 2 agents)
  staff.push({
    id: `${idPrefix}-agent-1`,
    role: ConsularRole.AGENT_CONSULAIRE,
    name: `Agent Consulaire 1 (${city})`,
    entityId: entity.id,
    hierarchyLevel: 5,
    employmentStatus: EmploymentStatus.CONTRACTUEL,
    allowedEntityTypes: [EntityType.CONSULAT_GENERAL, EntityType.CONSULAT, EntityType.AMBASSADE],
    permissions: ['Traitement dossiers', 'Guichet virtuel'],
    badge: '🟢',
    description: 'Agent de traitement - Guichet',
  });

  staff.push({
    id: `${idPrefix}-agent-2`,
    role: ConsularRole.AGENT_CONSULAIRE,
    name: `Agent Consulaire 2 (${city})`,
    entityId: entity.id,
    hierarchyLevel: 5,
    employmentStatus: EmploymentStatus.CONTRACTUEL,
    allowedEntityTypes: [EntityType.CONSULAT_GENERAL, EntityType.CONSULAT, EntityType.AMBASSADE],
    permissions: ['Traitement dossiers', 'Biométrie'],
    badge: '🟢',
    description: 'Agent de traitement - Biométrie',
  });

  // 6. STAGIAIRE (All entities)
  staff.push({
    id: `${idPrefix}-stagiaire`,
    role: ConsularRole.STAGIAIRE,
    name: `Stagiaire (${city})`,
    entityId: entity.id,
    hierarchyLevel: 6,
    employmentStatus: EmploymentStatus.CONTRACTUEL,
    allowedEntityTypes: [EntityType.CONSULAT_GENERAL, EntityType.CONSULAT, EntityType.AMBASSADE],
    permissions: ['Support traitement', 'Saisie données'],
    badge: '🎓',
    description: 'Stagiaire - Support Opérationnel',
  });

  return staff;
};

// Generate staff for all entities
const GENERATED_STAFF = MOCK_ENTITIES.flatMap(entity => generateStaffForEntity(entity));

// --- DYNAMIC STAFF GENERATION ---

// Convert detailed citizens to DemoUser
const MAPPED_CITIZENS: DemoUser[] = MOCK_GABONAIS_CITIZENS.map(c => ({
  id: c.id,
  role: ConsularRole.CITIZEN,
  name: `${c.firstName} ${c.lastName}`,
  entityId: c.assignedConsulate,
  permissions: ['Accès complet', 'Passeport', 'État Civil'],
  badge: '🇬🇦',
  description: `Citoyen Gabonais - ${c.profession}`,
  hierarchyLevel: 0,
  employmentStatus: EmploymentStatus.CITOYEN
}));

// Convert detailed foreigners to DemoUser
const MAPPED_FOREIGNERS: DemoUser[] = MOCK_FOREIGNERS.map(f => ({
  id: f.id,
  role: ConsularRole.FOREIGNER,
  name: `${f.firstName} ${f.lastName}`,
  entityId: f.assignedConsulate,
  permissions: ['Accès limité', 'Visa', 'Légalisation'],
  badge: '🌍',
  description: `Usager Étranger - ${f.nationality}`,
  hierarchyLevel: 0,
  employmentStatus: EmploymentStatus.CITOYEN
}));

export const MOCK_USERS: DemoUser[] = [
  ADMIN_USER,
  ...GENERATED_STAFF,
  ...MAPPED_CITIZENS,
  ...MAPPED_FOREIGNERS
];

export const getUserById = (id: string): DemoUser | undefined => {
  return MOCK_USERS.find(user => user.id === id);
};

export const getUsersByEntity = (entityId: string): DemoUser[] => {
  return MOCK_USERS.filter(user => user.entityId === entityId);
};
