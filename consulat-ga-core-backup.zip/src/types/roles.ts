import { ConsularRole, EmploymentStatus } from './consular-roles';
import { EntityType } from './entity';

export type UserRole = 'ADMIN' | ConsularRole;

export interface DemoUser {
  id: string;
  role: UserRole;
  name: string;
  entityId?: string; // null pour ADMIN système
  permissions: string[];
  badge: string; // emoji
  description: string;

  // New Hierarchy Fields
  hierarchyLevel?: number;
  employmentStatus?: EmploymentStatus;
  allowedEntityTypes?: EntityType[];
}
