export enum EntityType {
  AMBASSADE = 'AMBASSADE',
  CONSULAT = 'CONSULAT',
  CONSULAT_GENERAL = 'CONSULAT_GENERAL',
  HAUT_COMMISSARIAT = 'HAUT_COMMISSARIAT',
  MISSION_PERMANENTE = 'MISSION_PERMANENTE'
}

export interface Entity {
  id: string;
  type: EntityType;
  countryCode: string; // ISO 3166-1 alpha-2
  country: string;
  city: string;
  name: string;
  isActive: boolean;
  enabledServices: string[];

  // Extended Details
  address?: string;
  coordinates?: {
    lat: number;
    lng: number;
  };
  contact?: {
    phone: string;
    email: string;
    website?: string;
  };
  bankDetails?: {
    bankName: string;
    accountNumber: string;
    iban: string;
    swift: string;
    currency: string;
  };

  // Schedule & Planning
  openingHours?: {
    [key: string]: { // mon, tue, wed, thu, fri, sat, sun
      start: string; // "09:00"
      end: string;   // "17:00"
      isClosed: boolean;
    };
  };
}

export interface StaffPlanning {
  userId: string;
  shifts: {
    day: string; // mon, tue...
    start: string;
    end: string;
    type: 'ONSITE' | 'REMOTE' | 'OFF';
  }[];
}

export const COUNTRY_FLAGS: Record<string, string> = {
  // Europe
  FR: '🇫🇷',
  GB: '🇬🇧',
  DE: '🇩🇪',
  TR: '🇹🇷',
  CH: '🇨🇭',
  IT: '🇮🇹',
  // Afrique Australe
  ZA: '🇿🇦',
  AO: '🇦🇴',
  // Afrique Centrale
  CM: '🇨🇲',
  CG: '🇨🇬',
  CD: '🇨🇩',
  GQ: '🇬🇶',
  ST: '🇸🇹',
  // Afrique de l'Ouest
  SN: '🇸🇳',
  CI: '🇨🇮',
  TG: '🇹🇬',
  BJ: '🇧🇯',
  NG: '🇳🇬',
  ML: '🇲🇱',
  // Afrique du Nord
  MA: '🇲🇦',
  DZ: '🇩🇿',
  TN: '🇹🇳',
  EG: '🇪🇬',
  ET: '🇪🇹',
  // Amériques
  US: '🇺🇸',
  CA: '🇨🇦',
  CU: '🇨🇺',
  // Asie & Moyen-Orient
  CN: '🇨🇳',
  JP: '🇯🇵',
  KR: '🇰🇷',
  IN: '🇮🇳',
  SA: '🇸🇦',
  LB: '🇱🇧',
};
