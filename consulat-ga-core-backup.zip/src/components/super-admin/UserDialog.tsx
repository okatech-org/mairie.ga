import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ConsularRole } from "@/types/consular-roles";
import { DemoUser } from "@/types/roles";

interface UserDialogProps {
    open: boolean;
    onOpenChange: (open: boolean) => void;
    initialData?: DemoUser | null;
    onSave: (data: Partial<DemoUser>) => Promise<void>;
}

export function UserDialog({ open, onOpenChange, initialData, onSave }: UserDialogProps) {
    const [loading, setLoading] = useState(false);
    const [formData, setFormData] = useState<Partial<DemoUser>>({
        name: "",
        role: ConsularRole.CITIZEN,
        entityId: "",
    });

    useEffect(() => {
        if (initialData) {
            setFormData(initialData);
        } else {
            setFormData({
                name: "",
                role: ConsularRole.CITIZEN,
                entityId: "",
            });
        }
    }, [initialData, open]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        try {
            await onSave(formData);
            onOpenChange(false);
        } catch (error) {
            console.error("Failed to save", error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                    <DialogTitle>{initialData ? "Modifier l'Utilisateur" : "Nouvel Utilisateur"}</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4 py-4">
                    <div className="space-y-2">
                        <Label htmlFor="name">Nom complet</Label>
                        <Input
                            id="name"
                            value={formData.name}
                            onChange={(e) => setFormData(p => ({ ...p, name: e.target.value }))}
                            required
                        />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="role">Rôle</Label>
                        <Select
                            value={formData.role}
                            onValueChange={(v) => setFormData(p => ({ ...p, role: v as ConsularRole }))}
                        >
                            <SelectTrigger>
                                <SelectValue placeholder="Sélectionner un rôle" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="ADMIN">Super Admin</SelectItem>
                                <SelectItem value={ConsularRole.CONSUL_GENERAL}>Consul Général</SelectItem>
                                <SelectItem value={ConsularRole.CONSUL}>Consul</SelectItem>
                                <SelectItem value={ConsularRole.CITIZEN}>Citoyen</SelectItem>
                                <SelectItem value={ConsularRole.FOREIGNER}>Étranger</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="entityId">ID Entité (Optionnel)</Label>
                        <Input
                            id="entityId"
                            value={formData.entityId || ""}
                            onChange={(e) => setFormData(p => ({ ...p, entityId: e.target.value }))}
                            placeholder="ex: consulat-paris"
                        />
                    </div>
                    <DialogFooter>
                        <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Annuler</Button>
                        <Button type="submit" disabled={loading}>
                            {loading ? "Enregistrement..." : "Enregistrer"}
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
}
