import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { EntityType } from "@/types/entity";
import { Entity } from "@/types/entity";

interface OrganizationDialogProps {
    open: boolean;
    onOpenChange: (open: boolean) => void;
    initialData?: Entity | null;
    onSave: (data: Partial<Entity>) => Promise<void>;
}

export function OrganizationDialog({ open, onOpenChange, initialData, onSave }: OrganizationDialogProps) {
    const [loading, setLoading] = useState(false);
    const [formData, setFormData] = useState<Partial<Entity>>({
        name: "",
        type: EntityType.AMBASSADE,
        city: "",
        country: "",
        countryCode: "",
    });

    useEffect(() => {
        if (initialData) {
            setFormData(initialData);
        } else {
            setFormData({
                name: "",
                type: EntityType.AMBASSADE,
                city: "",
                country: "",
                countryCode: "",
            });
        }
    }, [initialData, open]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        try {
            await onSave(formData);
            onOpenChange(false);
        } catch (error) {
            console.error("Failed to save", error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                    <DialogTitle>{initialData ? "Modifier l'Organisation" : "Nouvelle Organisation"}</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4 py-4">
                    <div className="space-y-2">
                        <Label htmlFor="name">Nom de l'entité</Label>
                        <Input
                            id="name"
                            value={formData.name}
                            onChange={(e) => setFormData(p => ({ ...p, name: e.target.value }))}
                            required
                        />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="type">Type</Label>
                        <Select
                            value={formData.type}
                            onValueChange={(v) => setFormData(p => ({ ...p, type: v as EntityType }))}
                        >
                            <SelectTrigger>
                                <SelectValue placeholder="Sélectionner un type" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value={EntityType.AMBASSADE}>Ambassade</SelectItem>
                                <SelectItem value={EntityType.CONSULAT_GENERAL}>Consulat Général</SelectItem>
                                <SelectItem value={EntityType.CONSULAT}>Consulat</SelectItem>
                                <SelectItem value={EntityType.HAUT_COMMISSARIAT}>Haut-Commissariat</SelectItem>
                                <SelectItem value={EntityType.MISSION_PERMANENTE}>Mission Permanente</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label htmlFor="city">Ville</Label>
                            <Input
                                id="city"
                                value={formData.city}
                                onChange={(e) => setFormData(p => ({ ...p, city: e.target.value }))}
                                required
                            />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="country">Pays</Label>
                            <Input
                                id="country"
                                value={formData.country}
                                onChange={(e) => setFormData(p => ({ ...p, country: e.target.value }))}
                                required
                            />
                        </div>
                    </div>
                    <DialogFooter>
                        <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Annuler</Button>
                        <Button type="submit" disabled={loading}>
                            {loading ? "Enregistrement..." : "Enregistrer"}
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
}
