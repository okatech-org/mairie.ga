import { Users, Search, Filter, Shield, UserCheck, Plus, Briefcase, Globe, User } from "lucide-react";
import DashboardLayout from "@/layouts/DashboardLayout";
import { MOCK_USERS } from "@/data/mock-users";
import { useState } from "react";
import { ConsularRole } from "@/types/consular-roles";
import { UserDialog } from "@/components/super-admin/UserDialog";
import { useToast } from "@/components/ui/use-toast";
import { DemoUser } from "@/types/roles";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";

export default function SuperAdminUsers() {
    const { toast } = useToast();
    const [searchTerm, setSearchTerm] = useState("");
    const [isDialogOpen, setIsDialogOpen] = useState(false);
    const [selectedUser, setSelectedUser] = useState<DemoUser | null>(null);

    // Segmentation Logic
    const collaborators = MOCK_USERS.filter(u => u.role === 'ADMIN');
    const staff = MOCK_USERS.filter(u => Object.values(ConsularRole).includes(u.role as ConsularRole) && u.role !== ConsularRole.CITIZEN && u.role !== ConsularRole.FOREIGNER);
    const citizens = MOCK_USERS.filter(u => u.role === ConsularRole.CITIZEN);
    const foreigners = MOCK_USERS.filter(u => u.role === ConsularRole.FOREIGNER);

    const filterUsers = (users: DemoUser[]) => {
        return users.filter(user =>
            user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            (user.role && user.role.toLowerCase().includes(searchTerm.toLowerCase()))
        );
    };

    const handleAdd = () => {
        setSelectedUser(null);
        setIsDialogOpen(true);
    };

    const handleEdit = (user: DemoUser) => {
        setSelectedUser(user);
        setIsDialogOpen(true);
    };

    const handleSave = async (data: Partial<DemoUser>) => {
        await new Promise(resolve => setTimeout(resolve, 1000));
        toast({
            title: selectedUser ? "Utilisateur modifié" : "Utilisateur créé",
            description: `L'utilisateur ${data.name} a été enregistré.`,
        });
        setIsDialogOpen(false);
    };

    const getRoleBadgeColor = (role: string) => {
        switch (role) {
            case 'ADMIN': return 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400';
            case ConsularRole.CONSUL_GENERAL: return 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400';
            case ConsularRole.CITIZEN: return 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400';
            case ConsularRole.FOREIGNER: return 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400';
            default: return 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300';
        }
    };

    const UserTable = ({ users, showEntity = true }: { users: DemoUser[], showEntity?: boolean }) => (
        <div className="neu-raised rounded-xl overflow-hidden">
            <table className="w-full text-sm text-left">
                <thead className="text-xs text-muted-foreground uppercase bg-muted/50 border-b">
                    <tr>
                        <th className="px-6 py-4">Utilisateur</th>
                        <th className="px-6 py-4">Rôle</th>
                        {showEntity && <th className="px-6 py-4">Entité / Localisation</th>}
                        <th className="px-6 py-4">Statut</th>
                        <th className="px-6 py-4 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-border">
                    {users.map((user) => (
                        <tr key={user.id} className="hover:bg-muted/30 transition-colors">
                            <td className="px-6 py-4">
                                <div className="flex items-center gap-3">
                                    <div className="neu-inset w-10 h-10 rounded-full flex items-center justify-center text-lg">
                                        {user.badge || <UserCheck className="w-5 h-5" />}
                                    </div>
                                    <div>
                                        <div className="font-bold text-foreground">{user.name}</div>
                                        <div className="text-xs text-muted-foreground">{user.id}</div>
                                    </div>
                                </div>
                            </td>
                            <td className="px-6 py-4">
                                <span className={`px-2 py-1 rounded-full text-xs font-bold ${getRoleBadgeColor(user.role)}`}>
                                    {user.role.replace(/_/g, ' ')}
                                </span>
                            </td>
                            {showEntity && (
                                <td className="px-6 py-4 text-muted-foreground">
                                    {user.entityId || 'Global / N/A'}
                                </td>
                            )}
                            <td className="px-6 py-4">
                                <span className="flex items-center gap-1.5 text-green-600 dark:text-green-400 font-medium text-xs">
                                    <span className="w-1.5 h-1.5 rounded-full bg-green-600 dark:bg-green-400"></span>
                                    Actif
                                </span>
                            </td>
                            <td className="px-6 py-4 text-right">
                                <button
                                    onClick={() => handleEdit(user)}
                                    className="text-primary hover:underline font-medium"
                                >
                                    Éditer
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );

    return (
        <DashboardLayout>
            <div className="space-y-6">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                    <div>
                        <h1 className="text-3xl font-bold text-foreground">Utilisateurs</h1>
                        <p className="text-muted-foreground">
                            Gestion centralisée des accès et des comptes
                        </p>
                    </div>
                    <div className="neu-raised px-4 py-2 rounded-xl flex items-center gap-4 w-full md:w-auto">
                        <Search className="w-4 h-4 text-muted-foreground" />
                        <input
                            type="text"
                            placeholder="Rechercher..."
                            className="bg-transparent border-none focus:ring-0 text-sm w-full md:w-64"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                    </div>
                </div>

                <Tabs defaultValue="collaborators" className="w-full">
                    <TabsList className="w-full justify-start h-auto p-1 bg-muted/50 rounded-xl mb-6 overflow-x-auto">
                        <TabsTrigger value="collaborators" className="gap-2 px-4 py-2">
                            <Shield className="w-4 h-4" /> Collaborateurs
                        </TabsTrigger>
                        <TabsTrigger value="staff" className="gap-2 px-4 py-2">
                            <Briefcase className="w-4 h-4" /> Personnel Diplomatique
                        </TabsTrigger>
                        <TabsTrigger value="citizens" className="gap-2 px-4 py-2">
                            <User className="w-4 h-4" /> Citoyens Gabonais
                        </TabsTrigger>
                        <TabsTrigger value="foreigners" className="gap-2 px-4 py-2">
                            <Globe className="w-4 h-4" /> Usagers Étrangers
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="collaborators" className="space-y-4">
                        <div className="flex justify-between items-center">
                            <h2 className="text-lg font-bold">Collaborateurs Système</h2>
                            <Button onClick={handleAdd} className="gap-2">
                                <Plus className="w-4 h-4" /> Inviter un collaborateur
                            </Button>
                        </div>
                        <UserTable users={filterUsers(collaborators)} showEntity={false} />
                    </TabsContent>

                    <TabsContent value="staff" className="space-y-4">
                        <div className="flex justify-between items-center">
                            <h2 className="text-lg font-bold">Personnel des Organismes</h2>
                            <Button onClick={handleAdd} variant="outline" className="gap-2">
                                <Plus className="w-4 h-4" /> Ajouter un agent
                            </Button>
                        </div>
                        <UserTable users={filterUsers(staff)} />
                    </TabsContent>

                    <TabsContent value="citizens" className="space-y-4">
                        <div className="flex justify-between items-center">
                            <h2 className="text-lg font-bold">Citoyens Enregistrés</h2>
                        </div>
                        <UserTable users={filterUsers(citizens)} showEntity={true} />
                    </TabsContent>

                    <TabsContent value="foreigners" className="space-y-4">
                        <div className="flex justify-between items-center">
                            <h2 className="text-lg font-bold">Usagers Étrangers</h2>
                        </div>
                        <UserTable users={filterUsers(foreigners)} showEntity={true} />
                    </TabsContent>
                </Tabs>

                <UserDialog
                    open={isDialogOpen}
                    onOpenChange={setIsDialogOpen}
                    initialData={selectedUser}
                    onSave={handleSave}
                />
            </div>
        </DashboardLayout>
    );
}
